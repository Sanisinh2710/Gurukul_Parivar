import GujaratiJSON from './translation.json';

export {GujaratiJSON};
