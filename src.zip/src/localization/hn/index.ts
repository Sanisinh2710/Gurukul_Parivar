import HindiJSON from './translation.json';

export {HindiJSON};
