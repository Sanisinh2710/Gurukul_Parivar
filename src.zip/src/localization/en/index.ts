import EnglishJSON from './translation.json';

export {EnglishJSON};
