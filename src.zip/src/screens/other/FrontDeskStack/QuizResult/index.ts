export * from './QuizResult';
