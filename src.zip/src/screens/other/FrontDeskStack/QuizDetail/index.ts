export * from './DailyQuizDetail';
