export * from './DailyQuotes';
