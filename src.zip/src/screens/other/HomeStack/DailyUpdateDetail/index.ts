export * from './DailyUpdateDetail';
